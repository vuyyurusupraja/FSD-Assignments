# EncryptDecryptAndroid
A Sample app which helps to encrypt an audio file and decrypt to play back.

Watch the demo video here.
https://github.com/MrVipinVijayan/EncryptDecryptAndroid/blob/master/encrypt_decrypt_video_android.mp4
